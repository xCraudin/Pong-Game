#Biblioteca
import pygame, sys, time
from pygame.locals import *
from random import randint

#Setup PG Janela
mainClock = pygame.time.Clock()
from pygame.locals import *
pygame.init()
pygame.display.set_caption('Jogo')
screen = pygame.display.set_mode((500, 350),0,32)
lst_Hist = []
font = pygame.font.SysFont(None, 20)
 
def draw_text(text, font, color, surface, x, y):
    textobj = font.render(text, 1, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    surface.blit(textobj, textrect)

click = False

#Menu
def main_menu():
    while True:
 
        screen.fill((0,0,0))
        pygame.mouse.set_cursor(*pygame.cursors.diamond)
        fundo= pygame.image.load("pingpong.png")
        screen.blit(fundo,(0,0))
        mx, my = pygame.mouse.get_pos()
        

        #imagem
        estrela= pygame.image.load("estrelinha.png")
        setas=pygame.image.load("setas.png")
        awsd=pygame.image.load("awsd.png")
        bl = pygame.image.load("Bola.png").convert_alpha()
       
        
        #Escrita menu

        draw_text(' Bem vindo ao pong. ', font, (255, 255, 255), screen, 260, 70)
        draw_text(' Para jogar como player 1 ', font, (255, 255, 255), screen, 260, 90)
        draw_text(' Utilize as setas:  ', font, (255, 255, 255), screen, 260, 110)
        draw_text(' Para jogar como player 2 ', font, (255, 255, 255), screen, 260, 135)
        draw_text(' Utilize as teclas AWSD:  ', font, (255, 255, 255), screen, 260, 150)

        # texto
        texto1= font.render ("   Jogar   ", True, (255,255,255))
        texto1Rect= texto1.get_rect()
        texto1Rect.centerx= (100)
        texto1Rect.centery= (100)
        # texto
        texto2= font.render ("Histórico", True, (255,255,255))
        texto2Rect= texto2.get_rect()
        texto2Rect.centerx= (100)
        texto2Rect.centery= (180)
        # texto
        texto3= font.render ("    Exit    ", True, (255,255,255))
        texto3Rect= texto3.get_rect()
        texto3Rect.centerx= (100)
        texto3Rect.centery= (253)
                
        button_1 = pygame.draw.rect(screen, (255,0,0), (texto1Rect.left - 20, texto1Rect.top  - 20, texto1Rect.width + 40, texto1Rect.height + 40)) 
        button_2 = pygame.draw.rect(screen, (255,0,0), (texto2Rect.left - 20, texto2Rect.top  - 20, texto2Rect.width + 40, texto2Rect.height + 40))
        button_3 = pygame.draw.rect(screen, (255,0,0), (texto3Rect.left - 20, texto3Rect.top  - 20, texto3Rect.width + 40, texto3Rect.height + 40))
        screen.blit(texto1, texto1Rect)
        screen.blit(texto2, texto2Rect)
        screen.blit(texto3, texto3Rect)
        
        if button_1.collidepoint((mx, my)):
            if click:
                screen_jogo()
        if button_2.collidepoint((mx, my)):
            if click:               
                pygame.draw.rect(screen, (255,0,0), (texto1Rect.left - 20, texto1Rect.top  - 20, texto1Rect.width + 40, texto1Rect.height + 40)) 
                pygame.draw.rect(screen, (255,0,0), (texto2Rect.left - 20, texto2Rect.top  - 20, texto2Rect.width + 40, texto2Rect.height + 40))
                pygame.draw.rect(screen, (255,0,0), (texto3Rect.left - 20, texto3Rect.top  - 20, texto3Rect.width + 60, texto3Rect.height + 60))
                screen_historico(lst_Hist)  
        if button_3.collidepoint((mx,my)):
            if click:
                pygame.quit()
                sys.exit()
                    
        click = False
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True
        #Cursor
        pygame.mouse.set_visible(False)            
        x,y = pygame.mouse.get_pos()
        x -= bl.get_width()/2
        y -= bl.get_width()/2
        screen.blit(bl,(x,y))
        

                    
        
        #imagens tutorial
        
        screen.blit(awsd,(410,141))            
        screen.blit(setas,(360,110))

        #Linha de cima estrelas
        screen.blit(estrela,(240,45))
        screen.blit(estrela,(260,45))
        screen.blit(estrela,(280,45))
        screen.blit(estrela,(300,45))
        screen.blit(estrela,(320,45))
        screen.blit(estrela,(340,45))
        screen.blit(estrela,(360,45))
        screen.blit(estrela,(380,45))
        screen.blit(estrela,(400,45))
        screen.blit(estrela,(420,45))
        screen.blit(estrela,(440,45))

        #Linha de baixo estrelas
        screen.blit(estrela,(240,165))
        screen.blit(estrela,(260,165))
        screen.blit(estrela,(280,165))
        screen.blit(estrela,(300,165))
        screen.blit(estrela,(320,165))
        screen.blit(estrela,(340,165))
        screen.blit(estrela,(360,165))
        screen.blit(estrela,(380,165))
        screen.blit(estrela,(400,165))
        screen.blit(estrela,(420,165))
        screen.blit(estrela,(440,165))

        #Linha esquerda de estrelas
        screen.blit(estrela,(240,165))
        screen.blit(estrela,(240,145))
        screen.blit(estrela,(240,125))
        screen.blit(estrela,(240,105))
        screen.blit(estrela,(240,85))
        screen.blit(estrela,(240,65))
        screen.blit(estrela,(240,45))

        #Linha direita de estrelas
        screen.blit(estrela,(440,165))
        screen.blit(estrela,(440,145))
        screen.blit(estrela,(440,125))
        screen.blit(estrela,(440,105))
        screen.blit(estrela,(440,85))
        screen.blit(estrela,(440,65))
        screen.blit(estrela,(440,45))
               
        pygame.display.update()
        mainClock.tick(60)

#Tela jogo
def screen_jogo():
    pygame.init()
    nome1 = input("Nome do Jogador 1: ")
    nome2 = input("Nome do Jogador 2: ")
    WINDOW_WIDTH = 1024
    WINDOW_HEIGHT = 600

    clock = pygame.time.Clock()

    jogador1_win = False
    jogador2_win = False

    ### Informações goleiro ###
    goleiro_SPEED = 12

    UP1 = False
    DOWN1 = False
    NO_MOVEMENT1 = True

    UP2 = False
    DOWN2 = False
    NO_MOVEMENT2 = True

    ### Informações Bola ###
    UPLEFT = 0
    DOWNLEFT = 1
    UPRIGHT = 2
    DOWNRIGHT = 3

    ### Música ###
    pygame.mixer.music.load("Venice.ogg")
    sound_effect = pygame.mixer.Sound("bolha.wav")

    ### Load de Cores ###
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    ROSA = (255,20,147)
    VERMELHO = (255,0,0)
    AZUL = (0,139,139)

    ### Criando a superfície principal ###
    main_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), 0, 32)
    surface_rect = main_surface.get_rect()

    class goleiro(pygame.sprite.Sprite):
        def __init__(self, player_number):

            ### Criando o goleiro ###
            pygame.sprite.Sprite.__init__(self)

            self.player_number = player_number
            self.image = pygame.Surface([10, 100])
            self.image.fill(WHITE)
            self.rect = self.image.get_rect()
            self.speed = 8

            ### Estabelecendo o local de cada goleiro ##           
            if self.player_number == 1:
                self.rect.centerx = main_surface.get_rect().left
                self.rect.centerx += 50
            elif self.player_number == 2:
                self.rect.centerx = main_surface.get_rect().right
                self.rect.centerx -= 50
            self.rect.centery = main_surface.get_rect().centery



        def move(self):

            if self.player_number == 1:
                if (UP1 == True) and (self.rect.y > 5):
                    self.rect.y -= self.speed
                elif (DOWN1 == True) and (self.rect.bottom < WINDOW_HEIGHT-5):
                    self.rect.y += self.speed
                elif (NO_MOVEMENT1 == True):
                    pass

            if self.player_number == 2:
                if (UP2 == True) and (self.rect.y > 5):
                    self.rect.y -= self.speed
                elif (DOWN2 == True) and (self.rect.bottom < WINDOW_HEIGHT-5):
                    self.rect.y += self.speed
                elif (NO_MOVEMENT2 == True):
                    pass




    class bola(pygame.sprite.Sprite):
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)

            self.image = pygame.Surface([10, 10])
            self.image.fill(ROSA)
            self.rect = self.image.get_rect()
            self.rect.centerx = surface_rect.centerx
            self.rect.centery = surface_rect.centery
            self.direction = randint(0,3)
            self.speed = 4

        def move(self):
            if self.direction == UPLEFT:
                self.rect.x -= self.speed
                self.rect.y -= self.speed
            elif self.direction == UPRIGHT:
                self.rect.x += self.speed
                self.rect.y -= self.speed
            elif self.direction == DOWNLEFT:
                self.rect.x -= self.speed
                self.rect.y += self.speed
            elif self.direction == DOWNRIGHT:
                self.rect.x += self.speed
                self.rect.y += self.speed

        def change_direction(self):
            if self.rect.y < 0 and self.direction == UPLEFT:
                self.direction = DOWNLEFT
            if self.rect.y < 0 and self.direction == UPRIGHT:
                self.direction = DOWNRIGHT
            if self.rect.y > surface_rect.bottom and self.direction == DOWNLEFT:
                self.direction = UPLEFT
            if self.rect.y > surface_rect.bottom and self.direction == DOWNRIGHT:
                self.direction = UPRIGHT


        
            
    #Fonte das letras e palavras
    basic_font = pygame.font.SysFont("Helvetica", 120)
    game_over_font_big = pygame.font.SysFont("Helvetica", 72)
    game_over_font_small = pygame.font.SysFont("Helvetica", 50)




    goleiro1 = goleiro(1)
    goleiro2 = goleiro(2)

    bola = bola()

    all_sprites = pygame.sprite.RenderPlain(goleiro1, goleiro2, bola) 


    jogador1_score = 0
    jogador2_score = 0

    def goleiro_hit():
        if pygame.sprite.collide_rect(bola, goleiro2):
            if (bola.direction == UPRIGHT):
                bola.direction = UPLEFT
            elif (bola.direction == DOWNRIGHT):
                bola.direction = DOWNLEFT
            #Escalonamento da velocidade da bola 
            bola.speed += 0.5
            sound_effect.play()
            sound_effect.set_volume(0.4)  #volume do som
            
        elif pygame.sprite.collide_rect(bola, goleiro1):
            if (bola.direction == UPLEFT):
                bola.direction = UPRIGHT
            elif (bola.direction == DOWNLEFT):
                bola.direction = DOWNRIGHT
            #Escalonamento da velocidade da bola
            bola.speed += 0.5
            sound_effect.play()
            sound_effect.set_volume(0.4)  #volume do som

        
    counter = 0

    while True:

        clock.tick(60)

        if (bola.rect.x > WINDOW_WIDTH):
            bola.rect.centerx = surface_rect.centerx
            bola.rect.centery = surface_rect.centery
            bola.direction = randint(0, 1)
            bola.speed = 4
        elif (bola.rect.x < 0):
            bola.rect.centerx = surface_rect.centerx
            bola.rect.centery = surface_rect.centery
            bola.direction = randint(2, 3)
            bola.speed = 4


        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.mixer.music.pause()
                main_menu()
                                                        
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.mixer.music.pause()
                    main_menu()
                
                if event.key == ord('w'):
                    UP1 = True
                    DOWN1 = False
                    NO_MOVEMENT1 = False
                elif event.key == ord('s'):
                    UP1 = False
                    DOWN1 = True
                    NO_MOVEMENT1 = False
                    
                elif event.key == K_UP:
                    UP2 = True
                    DOWN2 = False
                    NO_MOVEMENT2 = False
                elif event.key == K_DOWN:
                    UP2 = False
                    DOWN2 = True
                    NO_MOVEMENT2 = False
                    
                
            elif event.type == KEYUP:
                if event.key == ord('w') or event.key == ord('s'):
                    NO_MOVEMENT1 = True
                    DOWN1 = False
                    UP1 = False
                elif event.key == K_DOWN or event.key == K_UP:
                    NO_MOVEMENT2 = True
                    DOWN2 = False
                    UP2 = False


    #Scoreboard no jogo
        score_board = basic_font.render(str(jogador1_score) + "           " + str(jogador2_score), True, WHITE, BLACK) 
        score_board_rect = score_board.get_rect()
        score_board_rect.centerx = surface_rect.centerx 
        score_board_rect.y = 10

        
        

        main_surface.fill(BLACK)

        main_surface.blit(score_board, score_board_rect)

        netx = surface_rect.centerx

    #Posicionamento da REDE (Pontos vermelhos)
        net_rect0 = pygame.Rect(netx, 0, 5, 600)
        
            
        #Rede (Rede azul na tela)
        pygame.draw.rect(main_surface, AZUL, (netx, 0, 5, 600))



        #Tela Placar
        pygame.draw.rect(main_surface, AZUL, (300, 25, 70, 5))
        pygame.draw.rect(main_surface, AZUL, (300, 128, 70, 5))

        

        pygame.draw.rect(main_surface, AZUL, (650, 128, 70, 5))
        pygame.draw.rect(main_surface, AZUL, (650, 25, 70, 5))

        #E
        pygame.draw.rect(main_surface, AZUL, (300, 25, 5, 107))
        pygame.draw.rect(main_surface, AZUL, (370, 25, 5, 108))

        #D
        pygame.draw.rect(main_surface, AZUL, (720, 25, 5, 108))
        pygame.draw.rect(main_surface, AZUL, (650, 25, 5, 107))


        #D linha fundo
        pygame.draw.rect(main_surface, AZUL, (0, 0, 5, 600))

        #E linha fundo
        pygame.draw.rect(main_surface, AZUL, (1019, 0, 5, 600))

        #E linha topo
        pygame.draw.rect(main_surface, AZUL, (0, 0, 1019, 5))

        #D linha baixo
        pygame.draw.rect(main_surface, AZUL, (0, 595, 1019, 5))


        all_sprites.draw(main_surface)

        goleiro1.move()
        goleiro2.move()
        bola.move()
        bola.change_direction()

        goleiro_hit()

        if bola.rect.x > WINDOW_WIDTH:
            jogador1_score += 1
        elif bola.rect.x < 0:
            jogador2_score += 1

        

        pygame.display.update()
        
        if counter == 0:
            time.sleep(1.5)
            pygame.mixer.music.play()
            pygame.mixer.music.set_volume(0.3)  #volume do som

        #Score para ganhar o jogo
        if jogador1_score == 5:
            jogador1_win = True
            break
        elif jogador2_score == 5:
            jogador2_win = True
            break

        counter += 1

    while True:

        for event in pygame.event.get():
            if event.type == QUIT:
                main_menu()

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    main_menu()

        main_surface.fill(BLACK)

    #Tela de fim de jogo
        if jogador1_win == True:
            game_over = game_over_font_big.render("Fim de jogo", True, WHITE, BLACK)
            game_over1 = game_over_font_small.render(f'{nome1} ganhou!', True, WHITE, BLACK)
            
        elif jogador2_win == True:
            game_over = game_over_font_big.render("Fim de jogo", True, WHITE, BLACK)
            game_over1 = game_over_font_small.render(f'{nome2} ganhou!', True, WHITE, BLACK)
            
        game_over_rect = game_over.get_rect()
        game_over_rect.centerx = surface_rect.centerx
        game_over_rect.centery = surface_rect.centery - 50
        game_over1_rect = game_over1.get_rect()
        game_over1_rect.centerx = game_over_rect.centerx
        game_over1_rect.centery = game_over_rect.centery + 75

        main_surface.blit(game_over, game_over_rect)
        main_surface.blit(game_over1, game_over1_rect)

        pygame.display.update()
        break
    placar = [nome1, str(jogador1_score), nome2, str(jogador2_score)]
    lst_Hist.append(placar)
    time.sleep(3)
    pygame.mixer.music.pause()
    main_menu()
    return lst_Hist

def screen_historico(lst_Hist):
    largura = 500
    altura = 350
    screen_Hist = pygame.display.set_mode((largura, altura),0,32)
    aux_Surface = screen_Hist.get_rect()
    pygame.display.set_caption('Histórico de Partida')
    lst_Hist = lst_Hist
    screen.fill((0,0,0))
    txt1 = 'Jogador 1: '
    txt2 = f'Score {txt1}: '
    txt3 ='Jogador 2: '
    txt4 =f'Score {txt3}: '
    
    fontesys=pygame.font.SysFont('Times New Roman', 16)
    
    txttela1 = fontesys.render(txt1, True, (255,255,255))
    txttela2 = fontesys.render(txt2, True, (255,255,255))
    txttela3 = fontesys.render(txt3, True, (255,255,255))      #Cor do texto
    txttela4 = fontesys.render(txt4, True, (255,255,255))
    
    screen.blit(txttela1,(10,10))
    screen.blit(txttela2,(10,30))
    screen.blit(txttela3,(10,50)) #Localização do texto na tela
    screen.blit(txttela4,(10,70))
    
    pygame.display.flip()
    
    '''for i in lst_Hist:
        for ii in lst_Hist:
            if ii == 0:
                
            elif ii == 1:
                
            elif ii == 2:
                
            elif ii == 3:'''
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            main_menu()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                main_menu()
    
 
main_menu()
